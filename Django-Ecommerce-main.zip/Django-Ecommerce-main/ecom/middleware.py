from django.utils import timezone
from store.models import Product

class RemoveExpiredProductsMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        
    def __call__(self, request):
        now = timezone.now()
        expired_products = Product.objects.filter(expired_date__lt=now)
        expired_products.delete()
        
        response = self.get_response(request)
        return response